============================================================
  dIctA - Dictado por Voz para Windows
  Desarrollado por InnovaAI
  https://innovaai-landing.onrender.com/es/
============================================================

INICIO RAPIDO
-------------
1. Ejecuta dIctA.exe (te pedira configurar tu clave API)
2. Obtene tu clave gratis en: https://console.groq.com/keys
3. Pega la clave en dicta.toml y guarda el archivo
4. Ejecuta dIctA.exe de nuevo

USO
---
- Manten presionada F9 para dictar (push-to-talk)
- Doble-tap F9 para modo manos libres
- El texto se pega automaticamente donde este el cursor
- Cambia la tecla editando "hotkey" en dicta.toml

MENU DE BANDEJA
---------------
Click derecho en el icono verde de la bandeja del sistema:
- Copiar ultima transcripcion
- Preferencias (abre dicta.toml)
- Historial
- Acerca de dIctA

REQUISITOS
----------
- Windows 10 o superior
- Conexion a internet
- Clave API de Groq (gratis) o OpenAI

SOPORTE
-------
https://innovaai-landing.onrender.com/es/

============================================================
  dIctA v1.0.0 - InnovaAI
============================================================
